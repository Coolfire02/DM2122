#include "Scene1.h"
#include "GL\glew.h"

#include "shader.hpp"


Scene1::Scene1()
{
}

Scene1::~Scene1()
{
}

void Scene1::Init()
{
	// Init VBO here
}

void Scene1::Update(double dt)
{
}

void Scene1::Render()
{
	// Render VBO here
}

void Scene1::Exit()
{
	// Cleanup VBO here
}
